var cadpat;
(function (cadpat) {
    'use strict';
    angular.module('cadpat', [
        'ngRoute',
        'ui.bootstrap',
        'bemControllers',
        'cadpatFilters',
        'cadpatServices',
        'alertaControllers',
        'alertaServices'
    ]);
})(cadpat || (cadpat = {}));
