(function(angular, undefined) {
    'use strict';

    angular.module('cadpat', [
        'ngRoute',
        'bemControllers'
    ]);

})(angular);
