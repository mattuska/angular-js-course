var cadpat;
(function (cadpat) {
    'use strict';
    angular.module('cadpat', [
        'ngRoute',
        'bemControllers'
    ]);
})(cadpat || (cadpat = {}));
